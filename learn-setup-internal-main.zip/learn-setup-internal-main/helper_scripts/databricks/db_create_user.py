import requests
import json
import yaml

def main(username):
    db_creds = get_db_creds()
    base_url, headers = base_url_headers(db_creds)
    
    # users = get_users(db_creds, base_url, headers)
    # print(users)

    print(f'[Databricks] Creating user account for {username}:')

    ## Create new user
    new_user = create_user(db_creds, base_url, headers, username)
    new_user_status = new_user.status_code
    new_user_info = new_user.json()

    if new_user_status == 201:
        print('Created \u2714', end=" ")
        user_id = new_user_info['id']
    elif new_user_status == 409:
        print('Exists \u2714', end=" ")
        user_id = get_user_id(db_creds, base_url, headers, username)
    else:
        print('Error in creation of user')

    # Enroll the learner in a group

    add_to_group = add_user_to_group(db_creds, base_url, headers, user_id)

    if add_to_group.status_code == 200:
        print('Add to group \u2714')
    else:
        print('Error in adding to group')


def get_db_creds():
    print("hello!")
    with open("./creds/databricks_creds.yml", 'r') as file:
        try:
            db_creds = yaml.safe_load(file)
        except yaml.YAMLError as exc:
            print(exc)
    return db_creds

def base_url_headers(db_creds):
    base_url = 'https://' + db_creds['machine']
    headers =  {
    'authorization': 'Bearer %s' % db_creds['password'],
    'Content-type': 'application/scim+json'
    }
    return base_url, headers

def get_users(db_creds, base_url, headers):

    url = base_url + '/api/2.0/preview/scim/v2/Users'
    params = {
    'cluster_id': db_creds['cluster']
    }  

    r = requests.get(
        url = url,
        headers = headers,
        params = params
    )

    return json.dumps(json.loads(r.text), indent = 2)

def create_user(db_creds, base_url, headers, username):

    url = base_url + '/api/2.0/preview/scim/v2/Users'

    data = {
        "schemas": [ "urn:ietf:params:scim:schemas:core:2.0:User" ],
        "userName": username
    }

    r = requests.post(
        url = url,
        headers = headers,
        data = json.dumps(data)
    )

    return r

def add_user_to_group(db_creds, base_url, headers, user_id):

    group_id = 381725646994870

    url = base_url + f"/api/2.0/preview/scim/v2/Groups/{group_id}"

    params = {
        'cluster_id': db_creds['cluster']
    }  

    data = {
        "schemas": [ "urn:ietf:params:scim:api:messages:2.0:PatchOp" ],
        "Operations": [
        {
        "op":"add",
        "value": {
            "members": [
            {
                "value": user_id
            }
            ]
        }
        }
    ]
    }

    r = requests.patch(
        url = url,
        headers = headers,
        data = json.dumps(data)
    )

    return r

def get_user_id(db_creds, base_url, headers, username):

    url = base_url + "/api/2.0/preview/scim/v2/Users" #+ f"?filter=userName+eq+{username}"

    params = {
        "cluster_id": db_creds['cluster'],
        "filter": f"userName eq {username}"
    }

    r = requests.get(
        url = url,
        headers = headers,
        params = params
    )

    user_info_dict = r.json()

    user_id = user_info_dict['Resources'][0]['id']

    return user_id

def get_groups(db_creds, base_url, headers):

    url = base_url + '/api/2.0/preview/scim/v2/Groups'
    
    params = {
    'cluster_id': db_creds['cluster']
    }  

    r = requests.get(
        url = url,
        headers = headers,
        params = params
    )

    return json.dumps(json.loads(r.text), indent = 2)

if __name__ == "__main__":
    main()


## check mark
print("Message \u2714", end=" ")